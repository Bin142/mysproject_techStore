package com.binhle.storetech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoretechApplicationTests {

	@Test
	void contextLoads() {
	}

}
